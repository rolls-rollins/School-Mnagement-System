 <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Student Management System
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2023.</strong> All rights reserved.
  </footer>