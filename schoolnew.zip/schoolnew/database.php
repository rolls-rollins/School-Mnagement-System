<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "schoolnew";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection

if (!$conn){
    die('error connecting to database');
}else{
    mysqli_select_db($conn, $dbname);
}